from flask_restx import Api
from flask import Blueprint

import main.config
from main.controller.tag_baselilne_controller import api as baseline_ns
from main.controller.tag_posture_controller import api as posture_ns
from flask import Flask


from pymongo import MongoClient
from flask_bcrypt import Bcrypt

from main import config
db = MongoClient()  # configure db url


blueprint = Blueprint('api', __name__)
authorizations = {
    'apikey': {
        'type': 'apiKey',
        'in': 'header',
        'name': 'Authorization'
    }
}

api = Api(
    blueprint,
    title='FLASK RESTPLUS(RESTX) API CORESTACK',
    version='1.0',
    description='a corestack for flask restplus (restx) web service',
    authorizations=authorizations,
    security='apikey'
)

#api.add_namespace(baseline_ns, path='/baseline')
#api.add_namespace(visibility_ns, path='/visibility')
#api.add_namespace(posture_ns, path='/posture')
def create_app(config_name: str) -> Flask:
    app = Flask(__name__)
    app.config.from_object(config)
    db.init_app(db)
    Bcrypt.init_app(app)

    return app
from flask import request
from flask_restx import Resource

from main.util.dto import  VisibilityDto
from main.service import tag_visibility_srv
api = VisibilityDto.api
from typing import Dict, Tuple


tag_visibility_srv=tag_visibility_srv.Tag_visibility_srv()

#import logging

from flask import request
from flask_restx import Resource,Api
#from restplus_api.api.business import create_category, delete_category, update_category
#from rest_api_demo.api.blog.serializers import category, category_with_posts
#from main.api.restplus import api
from main.model import database

#log = logging.getLogger(__name__)

ns = Api.namespace('/tag_visibility', description='Operations related to blog categories')





"""

get the taglist from corestack db by tenantId and store in mongodb

"""
@ns.route('/')
class Tag_Visibility(Resource):
    #@ns.route('/<tenantId>')
    @ns.response(201, 'taglist stored successfully.')
    @ns.doc('create taglist by tenantId from corestack')
    #@api.marshal_with(_user)
    def get(self, public_id):
        """get a user given its identifier"""
        taglist_by_tenantId = request.json
        return tag_visibility_srv.get_tagList_by_tenantId(taglist_by_tenantId)

"""
@api.route('/taglist/get_tagList_by_tenantId/<string:tenantId>/', methods=['POST'])
def get_tagList_by_tenantId():
    if request.method == "POST":
        corpus_list=request.json
        response = tag_visibility_srv.get_tagList_by_tenantId(corpus_list)
        return response, 201




 get the taglist from corestack db by serviceAcctId and store in mongodb




#@api.route('/taglist/get_tagList_by_serviceAcctId/<string:serviceAcctId>/', methods=['POST'])
def get_tagList_by_serviceAcctId():
    if request.method == "POST":
        corpus_list=request.json
        response = tag_visibility_srv.get_tagList_by_serviceAcctId(corpus_list)
        return response, 201
"""
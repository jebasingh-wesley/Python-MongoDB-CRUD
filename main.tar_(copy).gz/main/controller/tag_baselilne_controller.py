from flask import request
from flask_restx import Resource

from main.util.dto import BaselineDto
from main.service import tag_baseline_srv
api = BaselineDto.api


tag_baseline_srv=tag_baseline_srv.Tag_baseline_srv()
"""

get the  baseline taglist  for corestack from mongo database and send to corestack

"""

@api.route('/taglist/corestack_baseline_taglist/', methods=['GET'])
def corestack_baseline_taglist(todo_id):
    return tag_baseline_srv.get_baseline_taglist_corestack(), 200

"""

get the  baseline taglist by tenantId for corestack from mongo database and send to corestack.io

"""


@api.route('/taglist/get_baseline_taglist_by_tenantId/<string:tenantId>/', methods=['GET'])
def get_task(tenantId):
    return tag_baseline_srv.get_baseline_taglist_by_tenantId(tenantId), 200


"""

get the  baseline taglist by serviceAcctId for corestack from mongo database and send to corestack.io

"""


@api.route('/taglist/get_baseline_taglist_by_serviceAcctId/<string:serviceAcctId>/', methods=['GET'])
def get_task(serviceAcctId):
    return tag_baseline_srv.get_baseline_taglist_by_serviceAcctId(serviceAcctId), 200


"""

create baseline taglist for corestack and store in our mongo db

"""


@api.route('/taglist/create_baseline_taglist_corestack/', methods=['POST'])
def create_baseline_taglist_corestack():
    if request.method == "POST":
        corpus_list=request.json
        response = tag_baseline_srv.create_baseline_taglist_corestack(corpus_list)
        return response, 201


"""

create baseline taglist for corestack by tenantId or serviceAcctId and store in our mongo db

"""


@api.route('/taglist/create_baseline_taglist/<string:tenantId>/', methods=['POST'])
def create_baseline_taglist(tenantId):
    if request.method == "POST":
        corpus_list=request.json
        response = tag_baseline_srv.create_baseline_taglist(tenantId,corpus_list)
        return response, 201


"""

update whole baseline taglist of corestack in our mongo db

"""


@api.route('/todos/update_baseline_taglist_corestack/', methods=['PUT'])
def update_baseline_taglist_corestack():
    if request.method == "PUT":
        """title = request.form['title']
        body = request.form['body']"""
        updated_corpus=request.json
        response = tag_baseline_srv.update_baseline_taglist_corestack(updated_corpus)
        return response, 201


"""

update baseline taglist by tenantId or serviceAccountId in our mongo db

"""


@api.route('/todos/update_baseline_taglist/<string:tenantId>/', methods=['PUT'])
def update_baseline_taglist(tenantId):
    if request.method == "PUT":
        """title = request.form['title']
        body = request.form['body']"""
        updated_corpus=request.json
        response = tag_baseline_srv.update_baseline_taglist(tenantId, updated_corpus)
        return response, 201


"""

delete baseline taglist of corestack in our mongo db

"""


@api.route('/todos/delete_baseline_taglist_corestack/', methods=['DELETE'])
def delete_baseline_taglist_corestack():
    if request.method == "DELETE":
        tag_baseline_srv.delete_baseline_taglist_corestack()
        return "Record Deleted"


"""

delete baseline taglist of corestack ny tenantId or serviceAccountId in our mongo db

"""


@api.route('/todos/delete_baseline_taglist/<string:tenantId>/', methods=['DELETE'])
def delete_baseline_taglist(tenantId):
    if request.method == "DELETE":
        tag_baseline_srv.delete_baseline_taglist(tenantId)
        return "Record Deleted"
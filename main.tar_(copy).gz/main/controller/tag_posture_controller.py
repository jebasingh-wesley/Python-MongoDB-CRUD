from flask import request
from flask_restx import Resource

from main.util.dto import PostureDto
from main.service import tag_posture_srv
api = PostureDto.api


tag_posture_srv=tag_posture_srv.Tag_posture_srv()


"""

get tag posture list by tenantId and send to corestack db

"""


@api.route('/get_tagposture_by_tenantId/<string:todo_id>/', methods=['GET'])
def get_tagposture_by_tenantId(todo_id):
    return tag_posture_srv.get_tagposture_by_tenantId(todo_id), 200


"""

get tag posture list by serviceAccountId and send to corestack db

"""


@api.route('/get_tagposture_by_serviceacctId/<string:todo_id>/', methods=['GET'])
def get_tagposture_by_serviceacctId(todo_id):
    return tag_posture_srv.get_tagposture_by_serviceacctId(todo_id), 200

from flask import Flask, request, jsonify
from flask_cors import CORS  # to avoid cors error in different frontend like react js or any other
from main.service import tag_visibility_srv,tag_baseline_srv,tag_posture_srv
from flask import Flask
from flask_restx import Resource, Api
app = Flask(__name__)                  #  Create a Flask WSGI application
api = Api(app)

tag_visibility_srv=tag_visibility_srv.Tag_visibility_srv()
tag_baseline_srv=tag_baseline_srv.Tag_baseline_srv()
tag_posture_srv=tag_posture_srv.Tag_posture_srv()

# todo routes


@api.route('/baseline/<id>')
@api.response(404, 'Category not found.')
class CategoryItem(Resource):

    def get(self, id):
        """Returns details of a category."""
        return tag_baseline_srv.get_baseline_taglist_by_tenantId(id), 200

    @api.response(204, 'Category successfully updated.')
    def put(self, id):
        """Updates a blog category."""
        updated_corpus = request.json
        response = tag_baseline_srv.update_baseline_taglist(id, updated_corpus)
        return response, 200

    @api.response(204, 'Category successfully deleted.')
    def delete(self, id):
        """Deletes blog category."""
        tag_baseline_srv.delete_baseline_taglist(id)
        return "Record Deleted", 201


"""
get the taglist from corestack db by tenantId and store in mongodb
"""

#@app.route('/taglist/get_tagList_by_tenantId/<string:tenantId>/', methods=['POST'])

@app.route('/taglist/get_tagList_by_tenantId/', methods=['POST'])
def get_tagList_by_tenantId():
    if request.method == "POST":
        corpus_list=request.json
        response = tag_visibility_srv.get_tagList_by_tenantId(corpus_list)
        return response, 201


"""
 get the taglist from corestack db by serviceAcctId and store in mongodb
"""


@app.route('/taglist/get_tagList_by_serviceAcctId/<string:serviceAcctId>/', methods=['POST'])
def get_tagList_by_serviceAcctId():
    if request.method == "POST":
        corpus_list=request.json
        response = tag_visibility_srv.get_tagList_by_serviceAcctId(corpus_list)
        return response, 201


"""
get the  baseline taglist  for corestack from mongo database and send to corestack
"""


@app.route('/taglist/get_baseline_taglist_corestack/', methods=['GET'])
def get_baseline_taglist_corestack():
    if request.method == "GET":
        print(tag_baseline_srv.get_baseline_taglist_corestack())
        return tag_baseline_srv.get_baseline_taglist_corestack(),200


"""
get the  baseline taglist by tenantId for corestack from mongo database and send to corestack.io
"""


@app.route('/taglist/get_baseline_taglist_by_tenantId/<string:tenantId>/', methods=['GET'])
def get_baseline_taglist_by_tenantId(tenantId):
    return tag_baseline_srv.get_baseline_taglist_by_tenantId(tenantId), 200


"""
get the  baseline taglist by serviceAcctId for corestack from mongo database and send to corestack.io
"""


@app.route('/taglist/get_baseline_taglist_by_serviceAcctId/<string:serviceAcctId>/', methods=['GET'])
def get_baseline_taglist_by_serviceAcctId(serviceAcctId):
    return tag_baseline_srv.get_baseline_taglist_by_serviceAcctId(serviceAcctId), 200


"""
create baseline taglist for corestack and store in our mongo db
"""


@app.route('/taglist/create_baseline_taglist_corestack/', methods=['POST'])
def create_baseline_taglist_corestack():
    if request.method == "POST":
        corpus_list=request.json
        response = tag_baseline_srv.create_baseline_taglist_corestack(corpus_list)
        return response, 201


"""
create baseline taglist for corestack by tenantId or serviceAcctId and store in our mongo db
"""


@app.route('/taglist/create_baseline_taglist/<string:tenantId>/', methods=['POST'])
def create_baseline_taglist(tenantId):
    if request.method == "POST":
        corpus_list=request.json
        response = tag_baseline_srv.create_baseline_taglist(tenantId,corpus_list)
        return response, 201


"""
update whole baseline taglist of corestack in our mongo db
"""


@app.route('/taglist/update_baseline_taglist_corestack/', methods=['PUT'])
def update_baseline_taglist_corestack():
    if request.method == "PUT":
        """title = request.form['title']
        body = request.form['body']"""
        updated_corpus=request.json
        response = tag_baseline_srv.update_baseline_taglist_corestack(updated_corpus)
        print(response)
        return response, 201


"""
update baseline taglist by tenantId or serviceAccountId in our mongo db
"""


@app.route('/taglist/update_baseline_taglist/<string:tenantId>/', methods=['PUT'])
def update_baseline_taglist(tenantId):
    if request.method == "PUT":
        """title = request.form['title']
        body = request.form['body']"""
        updated_corpus=request.json
        response = tag_baseline_srv.update_baseline_taglist(tenantId, updated_corpus)
        return response, 201


"""
delete baseline taglist of corestack in our mongo db
"""


@app.route('/todos/delete_baseline_taglist_corestack/', methods=['DELETE'])
def delete_baseline_taglist_corestack():
    if request.method == "DELETE":
        tag_baseline_srv.delete_baseline_taglist_corestack()
        return "Record Deleted"


"""
delete baseline taglist of corestack ny tenantId or serviceAccountId in our mongo db
"""


@app.route('/taglist/delete_baseline_taglist/<string:tenantId>/', methods=['DELETE'])
def delete_baseline_taglist(tenantId):
    if request.method == "DELETE":
        tag_baseline_srv.delete_baseline_taglist(tenantId)
        return "Record Deleted"


"""
get tag posture list by tenantId and send to corestack db
"""


@app.route('/todos/get_tagposture_by_tenantId/<string:todo_id>/', methods=['GET'])
def get_tagposture_by_tenantId(todo_id):
    return tag_posture_srv.get_tagposture_by_tenantId(todo_id), 200


"""
get tag posture list by serviceAccountId and send to corestack db
"""


@app.route('/todos/get_tagposture_by_serviceacctId/<string:todo_id>/', methods=['GET'])
def get_tagposture_by_serviceacctId(todo_id):
    return tag_posture_srv.get_tagposture_by_serviceacctId(todo_id), 200

if __name__ == '__main__':
    app.run(debug=True)

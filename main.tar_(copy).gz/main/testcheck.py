from pathlib import Path

import os
from spellchecker import SpellChecker

# pypi
from dotenv import load_dotenv

# this repo
from main.util.edits import TheEditor
from main.util.preprocessing import CorpusBuilder

load_dotenv("/etc/environment", override=True)
path = Path(os.environ["SHAKESPEARE"])
#path1 = Path(os.environ["DICT"])

corpus = CorpusBuilder(path)
#corpus1 = CorpusBuilder(path1)

def edit_one_letter(word: str, allow_switches: bool=True) -> set:
    """Get all possible words one edit away from the original

    Args:
      word: word for which we will generate all possible words one edit away.

    Returns:
      edit_one_set: a set of words with one possible edit.
    """

    edit_one_set = set()

    editor = TheEditor(word)
    edits = editor.replaced + editor.inserted + editor.deleted
    if allow_switches:
        edits += editor.switched
    edit_one_set = set(edits)

    return edit_one_set



tmp_word = "at"
tmp_edit_one_set = edit_one_letter(tmp_word)
# turn this into a list to sort it, in order to view it
tmp_edit_one_l = sorted(list(tmp_edit_one_set))

#print(f"input word {tmp_word} \nedit_one_l \n{tmp_edit_one_l}\n")
#print(f"The type of the returned object should be a set {type(tmp_edit_one_set)}")
#print(f"Number of outputs from edit_one_letter('at') is {len(edit_one_letter('at'))}")

expected = ['a', 'aa', 'aat', 'ab', 'abt', 'ac', 'act', 'ad', 'adt', 'ae', 'aet', 'af', 'aft', 'ag', 'agt', 'ah', 'aht', 'ai', 'ait', 'aj', 'ajt', 'ak', 'akt', 'al', 'alt', 'am', 'amt', 'an', 'ant', 'ao', 'aot', 'ap', 'apt', 'aq', 'aqt', 'ar', 'art', 'as', 'ast', 'ata', 'atb', 'atc', 'atd', 'ate', 'atf', 'atg', 'ath', 'ati', 'atj', 'atk', 'atl', 'atm', 'atn', 'ato', 'atp', 'atq', 'atr', 'ats', 'att', 'atu', 'atv', 'atw', 'atx', 'aty', 'atz', 'au', 'aut', 'av', 'avt', 'aw', 'awt', 'ax', 'axt', 'ay', 'ayt', 'az', 'azt', 'bat', 'bt', 'cat', 'ct', 'dat', 'dt', 'eat', 'et', 'fat', 'ft', 'gat', 'gt', 'hat', 'ht', 'iat', 'it', 'jat', 'jt', 'kat', 'kt', 'lat', 'lt', 'mat', 'mt', 'nat', 'nt', 'oat', 'ot', 'pat', 'pt', 'qat', 'qt', 'rat', 'rt', 'sat', 'st', 't', 'ta', 'tat', 'tt', 'uat', 'ut', 'vat', 'vt', 'wat', 'wt', 'xat', 'xt', 'yat', 'yt', 'zat', 'zt']

assert tmp_edit_one_l == expected
assert len(edit_one_letter("at")) == 129



def edit_two_letters(word: str, allow_switches: bool=True) -> set:
    """Make two-letter edits

    Args:
      word: the input string/word

    Returns:
       edit_two_set: a set of strings with all possible two edits
    """

    edit_two_set = set()

    ones = edit_one_letter(word, allow_switches)
    for word in ones:
        edit_two_set = edit_two_set.union(edit_one_letter(word, allow_switches))

    return edit_two_set


tmp_edit_two_set = edit_two_letters("a")
tmp_edit_two_l = sorted(list(tmp_edit_two_set))
twos = len(tmp_edit_two_l)

assert twos == 2654, twos
#print(f"Number of strings with edit distance of two: {twos}")

first_ten = tmp_edit_two_l[:10]
assert first_ten == ['', 'a', 'aa', 'aaa', 'aab', 'aac', 'aad', 'aae', 'aaf', 'aag']
#print(f"First 10 strings {first_ten}")

last_ten = tmp_edit_two_l[-10:]
assert last_ten == ['zv', 'zva', 'zw', 'zwa', 'zx', 'zxa', 'zy', 'zya', 'zz', 'zza']
#print(f"Last 10 strings {last_ten}")
#print(f"The data type of the returned object should be a set {type(tmp_edit_two_set)}")

actual = len(edit_two_letters('at'))
expected = 7154
assert expected == actual, actual
#print(f"Number of strings that are 2 edit distances from 'at' is {actual}")

#print( [] and ["a","b"] )
#print( [] or ["a","b"] )
#example of Short circuit behavior
val1 =  ["Most","Likely"] or ["Less","so"] or ["least","of","all"]  # selects first, does not evalute remainder
#print(val1)
val2 =  [] or [] or ["least","of","all"] # continues evaluation until there is a non-empty list
#print(val2)

def tag_autocheck(word):

    spell = SpellChecker()
    print('word::',word)
    misspelled = spell.unknown([word])
    for word in misspelled:
        # Get the one `most likely` answer
        #print(spell.correction(word))
        pass

        # Get a list of `likely` options
        #print(spell.candidates(word))
    return str(spell.correction(word))

def get_corrections(word: str, probs: dict, vocab: set, n: int=2, verbose: bool=False) -> list:
    """Gets corrections within n edits

    Args:
       word: a user entered string to check for suggestions
       probs: a dictionary that maps each word to its probability in the corpus
       vocab: a set containing all the vocabulary
       n: number of possible word corrections you want returned in the dictionary

    Returns:
       n_best: a list of tuples with the most probable n corrected words and their probabilities.
    """

    suggestions = []
    n_best = []

    if word in vocab:
        n_best = [(word, probs[word])]
    else:
        suggestions = vocab.intersection(edit_one_letter(word))
        print(suggestions)
        if not suggestions:
            suggestions = vocab.intersection(edit_two_letters(word))
            n_best = tag_autocheck(word)
            print(n_best)
        if suggestions:
            print('suggestion inside')
            probabilities = list(reversed(sorted([(probs.get(suggestion, 0), suggestion)
                                for suggestion in suggestions])))
            n_best = [(word, probability) for (probability, word) in probabilities[:n]]
            n_best=str(n_best[0])


    if verbose:
        if suggestions==[]:
            print('yes')


    return n_best





#activate


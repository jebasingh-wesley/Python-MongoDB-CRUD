import json

config = json.load(open('/home/ubuntu/Flask_project/main/db_config.json'))
from main.model.database import Database


class Tag_posture_srv(object):
    def __init__(self):
        self.db = Database()

        self.collection_name = 'corpus_list'

    def get_tagposture_by_tenantId(self, id):
        return self.db.find(id, self.collection_name)

    def get_tagposture_by_serviceacctId(self, id):
        return self.db.find(id, self.collection_name)
from main.model.database import Database


class Tag_visibility_srv(object):
    def __init__(self):
        self.db = Database()

        self.collection_name = 'corpus_list'
    def get_tagList_by_tenantId(self, tag_visibility_srv):
        # Validator will throw error if invalid
        res = self.db.insert(tag_visibility_srv, self.collection_name)
        return "Inserted Id " + res

    def get_tagList_by_serviceAcctId(self, tag_visibility_srv):
        # Validator will throw error if invalid
        res = self.db.insert(tag_visibility_srv, self.collection_name)
        return "Inserted Id " + res
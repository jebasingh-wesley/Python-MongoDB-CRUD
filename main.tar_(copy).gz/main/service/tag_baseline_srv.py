from main.model.database import Database



class Tag_baseline_srv(object):
    def __init__(self):
        self.db = Database()

        self.collection_name = 'corpus_list'

    def get_baseline_taglist_corestack(self):  # find all
        return self.db.find(self.collection_name)

    def get_baseline_taglist_by_tenantId(self, id):
        return self.db.find_by_id(id, self.collection_name)

    def get_baseline_taglist_by_serviceAcctId(self, id):
        return self.db.find_by_id(id, self.collection_name)

    def create_baseline_taglist_corestack(self, tag_baseline_srv):
        # Validator will throw error if invalid
        res = self.db.insert(tag_baseline_srv, self.collection_name)
        return "Inserted Id " + res

    def create_baseline_taglist(self, tag_baseline_srv):
        # Validator will throw error if invalid
        res = self.db.insert(id,tag_baseline_srv, self.collection_name)
        return "Inserted Id " + res

    def update_baseline_taglist_corestack(self, tag_baseline_srv):
        return self.db.update(tag_baseline_srv, self.collection_name)

    def update_baseline_taglist(self, id, tag_baseline_srv):
        return self.db.update_by_id(id, tag_baseline_srv, self.collection_name)

    def delete_baseline_taglist_corestack(self):
        return self.db.delete(self.collection_name)

    def delete_baseline_taglist(self, id):
        return self.db.delete_byId(id, self.collection_name)
